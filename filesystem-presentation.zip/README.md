# Boost.Graph - C++ User-Group Meeting - June, 2017

## Run
Simple type `npm install` and `grunt serve` will install and open the presentation in your browser.
